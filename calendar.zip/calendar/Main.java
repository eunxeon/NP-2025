package calendar;

public class Main {
    public static void main(String[] args) {
        // 로그인 화면부터 시작
        new LoginUI();
    }
}
